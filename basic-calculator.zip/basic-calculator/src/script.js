var num1;
var num2
var oper;
var display;
display = document.getElementById("text");
var symbols = ["+", "-", "*", "/"];
// equals = "=";

function cleardisplay(){
  display.innerHTML = '';
  console.log('cleared')
}

function writeSomething(number){
  var current;
  current = display.innerHTML;
  console.log(current);
  
  document.getElementById("text").innerHTML = current + number;
}

function operation(op){
  num1 = display.innerHTML;
  oper = op;
  display.innerHTML = '+';
}

function calculate(){
  // const str = '1+23+4+5-30';
  var eq = display.innerHTML;
  try {
    var result = eval(eq);
  } catch (error) {
  var result = 'INVALID SYNTAX';
  }
  // expected output: ReferenceError: nonExistentFunction is not defined
  // Note - error messages will vary depending on browser
    display.innerHTML = result;
  };
  
//   const str = '1+23+4+5-30';
// const compute = (str = '') => {
//    let total = 0;
//    str = str.match(/[+\−]*(\.\d+|\d+(\.\d+)?)/g) || [];
//    while (str.length) {
//       total += parseFloat(str.shift());
//    };
//    return total;
// };
// console.log(compute(str));
  // var eq = "35+53=";
  // var split_eq = eq.split(/["+", "-", "*", "/", "="]/);
  // console.log(split_eq);
  // var start = None;
  // var end = None;
  // console.log(symbols[1])
  // console.log(isNaN(0))
  // if (isNaN(display.innerHTML[0])){
        // display.innerHTML = "INVALID SYNTAX";
        // return;
      // };
  // for (var i=0; i<display.innerHTML.length; i++)
    // {
      // if (!isNaN(display.innerHTML[i])){
        // if (start==None){start=i;};
        // else{
          // if (isNaN(display.innerHTML[i+1])){
            // end = i;
//             
          // }
        // }
        
      
      // console.log("hElLo")
    // };
      // if (parseFloat(display.innerHTML.length[i])).isInteger){
        // pass
      // }
      // else{
        // equation_list.append(display.innerHTML.length[i])
        
      // }
    // }